# When Admin Web 1.0.0

Serve the contents of `site/` from a static web server. Configure that server
to route `/api/` and `/admin/` requests to the trusted-network When API. The
management console has no MVP authentication and must not be exposed publicly.
